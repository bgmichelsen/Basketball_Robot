/* Variables */
const FONT_SIZE = 20;  // Size of the font
const G = 9.8;         // Gravity constant
const MAX_DIST = 5;    // Maximum distance robot can be from hoop

let scale;             // Scaling factor for the calculations
let scaleSlider;       // Scale slider object
let hoop_x, hoop_y;    // x and y coords of the hoop center
let w;                 // Width of the shapes


/*
  Function to map a launch angle given a distance
  
  *  start_x = x coord of robot
  *  end_x = x coord of hoop
*/
function calc_theta(start_x, end_x) {
  let dist = (end_x - start_x)/10;  // Calculate the distance between the robot and the hoop
  return (-0.9*dist + 90);          // Linear mapping of distance to the angle
}


/* 
  Function to calculate the launch velocity using the trajectory displacement equation (see https://courses.lumenlearning.com/boundless-physics/chapter/projectile-motion/)
  
  The equation used is below:
    v = sqrt( G*dist^2 / (dist*tan(theta) - basket_height)*(2*cos^2(theta)) )
    
  *  theta = launch angle of projectile
  *  start_x, start_y = coordinates of robot
  *  end_x, end_y = coordinates of the basket hoop
*/
function calc_velocity(theta, start_x, start_y, end_x, end_y) {
  let angle = radians(theta);
  let cos2 = cos(angle)*cos(angle);                            // Cosine squared
  let x_dist = end_x - start_x;                                // Distance between robot and hoop (x displacement)
  let y_dist = -1*(end_y - start_y);                           // Distance from robot to hoop (y displacement)
  let denominator = ((x_dist*tan(angle) - y_dist)*(2*cos2));   // Bottom half of the given equation
  
  // If the bottom half of the equation is negative, make it positive
  if (denominator < 0) {
    denominator *= -1;
  }
  
  // Return the calculated velocity
  return sqrt((G*x_dist*x_dist)/denominator);
}


/*
  Function to draw the trajectory
  
  *  theta = launch angle
  *  velocity = initial velocity
  *  start_x, start_y = coordinates of the robot
  *  end_x, end_y = coordinates of the hoop
*/
function draw_trajectory(theta, velocity, start_x, start_y, end_x, end_y) {
  let angle = radians(theta);
  let cos2 = cos(angle)*cos(angle);        // Cosine squared
  let v2 = velocity*velocity;              // Velocity squared
  
  let dist_x = end_x - start_x;            // Displacement in the x direction
  let dist_y = end_y - start_y;            // Displacement in the y direction
  
  noFill();
  stroke(5);
  translate(start_x, start_y);            // Translate the origin to the robot
  
  // Draw a new shape (trajectory shape)
  beginShape();
    // If the angle is above 84 degrees, draw a simple line
    if (theta > 84) {
      line(0, 0, dist_x, dist_y);
    }
    // Otherwise, draw a parabola
    else {
      curveVertex(0, 0);                                      // Origin coordinate
      
      // Loop through all points in the parabola
      for (let x = 1; x <= dist_x; x++) {
        let y = -(x*tan(angle) - (G*(x*x))/(2*v2*cos2));      // Calculate the y coordinate using the trajectory displacement equation
        curveVertex(x, y);                                    // Add a point to the parabola
      }
    }
  endShape();
}


/*
  Setup Function
*/
function setup() {
  createCanvas(640, 480);
  hoop_x = width/2 + 100;    // Set the x coordinate of the hoop
  hoop_y = height - 216;     // Set the y coordinate of the hoop
  w = 20;                    // Set the size of the spheres
  textSize(FONT_SIZE);       // Set the size of the fonts
  
  scaleSlider = createSlider(10, 1000, 100, 10);
  scaleSlider.size(100);
  scaleSlider.position((width - 150), FONT_SIZE*2);
}


/*
  Draw Function
*/
function draw() {
   let x = 0; 
  
   clear();
   noStroke();
   
   scale = scaleSlider.value();
   
   fill(255, 0, 0);
   ellipse(hoop_x, hoop_y, w, w);
   
   fill(0, 0, 255);
   if (mouseX < hoop_x - MAX_DIST) {
     ellipse(mouseX, height - w, w, w);
     x = mouseX;
   }
   else {
     ellipse(hoop_x - MAX_DIST, height - w, w, w);
     x = hoop_x - MAX_DIST;
   }
   
   let theta = calc_theta(x, hoop_x);
   let velocity = calc_velocity(theta, x, (height - w), hoop_x, hoop_y);
   let velocity_scaled = calc_velocity(theta, x/scale, (height - x)/scale, hoop_x/scale, hoop_y/scale);
   
   fill(150, 150, 150);
   text("Launch Angle = " + nfc(theta, 2) + " deg", 10, FONT_SIZE);
   text("Launch Velocity = " + nfc(velocity_scaled, 2) + " m/s", 10, FONT_SIZE*2);
   text("Distance to Hoop = " + (hoop_x - x)/scale + " m", 10, FONT_SIZE*3);
   text("Height of the Hoop = " + (height - hoop_y)/scale + " m", 10, FONT_SIZE*4);
   text("SCALE: " + scale, width - 150, FONT_SIZE);
   
   draw_trajectory(theta, velocity, x, (height - w), hoop_x, hoop_y);
}
